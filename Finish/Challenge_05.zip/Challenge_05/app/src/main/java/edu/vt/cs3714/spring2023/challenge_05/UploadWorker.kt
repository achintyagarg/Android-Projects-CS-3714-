package edu.vt.cs3714.spring2023.challenge_05

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject

class UploadWorker(appContext: Context, workerParams: WorkerParameters)
    : Worker(appContext, workerParams) {

    override fun doWork(): Result {


        val json = JSONObject()
        json.accumulate("username",inputData.getString("username"))
        json.accumulate("event",inputData.getString("event"))
        Log.d(MainActivity.TAG, "params:"+json.toString()+ " url "+MainActivity.URL)
        return uploadLog(json, MainActivity.URL)
    }

    fun uploadLog(json: JSONObject, url: String): Result {
        Log.d(MainActivity.TAG, "uploadLog() $url")
        try {
            var call = TrackerService.create(url).postLog(json)
            var response = call.execute()


            if (response.isSuccessful) {
                Log.d(MainActivity.TAG, "Log uploaded successfully: ${response.body()}")
                return Result.success()
            } else {
                Log.e(MainActivity.TAG, "Failed to upload log: ${response.errorBody()?.string()}")
                return Result.failure()
            }
        } catch (e: Exception) {
            Log.e(MainActivity.TAG, "Error uploading log", e)
            return Result.retry()
        }
    }
}
